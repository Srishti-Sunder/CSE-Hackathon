"""Core domain logic for P13 Traffic Signal Fault Dispatcher."""
import re
from datetime import datetime, timezone

ZONES = ("NORTH", "SOUTH", "EAST", "WEST")
JUNCTION_RE = re.compile(r"^J(?:NORTH|SOUTH|EAST|WEST)[0-9]{3}$")
FAULT_RE = re.compile(r"^F[0-9]{2}$")
CATEGORIES = ("Arterial-Blocked", "Signal-Dark", "Partial-Fault", "Flashing-Mode", "Minor")
PRIORITIES = {
    "Arterial-Blocked": (1, "Critical"),
    "Signal-Dark": (1, "Critical"),
    "Partial-Fault": (2, "Medium"),
    "Flashing-Mode": (3, "Low"),
    "Minor": (4, "Lowest"),
}
# Demonstration-only mapping. The supplied problem statement does not define code meanings.
DEMO_CLASSIFICATION = {
    "F01": "Arterial-Blocked", "F02": "Signal-Dark",
    "F03": "Partial-Fault", "F04": "Flashing-Mode", "F05": "Minor",
}


def dfa_junction(value):
    """Exact DFA simulation: J -> one complete zone -> exactly three digits."""
    if not isinstance(value, str) or not value:
        return False
    state = "START"
    prefix = ""
    for ch in value:
        if state == "START":
            if ch != "J": return False
            state = "ZONE"
        elif state == "ZONE":
            prefix += ch
            if not any(z.startswith(prefix) for z in ZONES): return False
            if prefix in ZONES: state = "DIGIT1"
        elif state in ("DIGIT1", "DIGIT2", "DIGIT3"):
            if not ch.isascii() or not ch.isdigit(): return False
            state = {"DIGIT1": "DIGIT2", "DIGIT2": "DIGIT3", "DIGIT3": "DEAD"}[state]
        else:
            return False
    return state == "DEAD"


def dfa_fault(value):
    if not isinstance(value, str) or not value or value[0] != "F": return False
    state = "DIGIT1"
    for ch in value[1:]:
        if state not in ("DIGIT1", "DIGIT2") or not ch.isascii() or not ch.isdigit(): return False
        state = "DIGIT2" if state == "DIGIT1" else "DEAD"
    return state == "DEAD"


def validate(junction_id, fault_code):
    j_dfa, j_regex = dfa_junction(junction_id), bool(JUNCTION_RE.fullmatch(junction_id or ""))
    f_dfa, f_regex = dfa_fault(fault_code), bool(FAULT_RE.fullmatch(fault_code or ""))
    errors = []
    if not junction_id: errors.append("Junction ID is required.")
    elif not j_dfa: errors.append("Invalid junction ID. Expected JNORTH001, JSOUTH001, JEAST001 or JWEST001 format.")
    if not fault_code: errors.append("Fault code is required.")
    elif not f_dfa: errors.append("Invalid fault code. Expected F followed by exactly two digits (for example, F01).")
    if j_dfa != j_regex or f_dfa != f_regex:
        errors.append("Internal validation mismatch between DFA and regular expression.")
    return {"valid": not errors, "errors": errors, "dfa_regex_agree": j_dfa == j_regex and f_dfa == f_regex,
            "junction_dfa": j_dfa, "junction_regex": j_regex, "fault_dfa": f_dfa, "fault_regex": f_regex}


def classify(fault_code, rules=None):
    rules = rules or DEMO_CLASSIFICATION
    category = rules.get(fault_code)
    if category not in CATEGORIES:
        return None, None
    return category, f"Configured demonstration rule: {fault_code} → {category}"


def zone_from_junction(junction_id):
    if not dfa_junction(junction_id):
        raise ValueError("Cannot extract a zone from an invalid junction ID.")
    return junction_id[1:-3].title()


def utcnow():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")
