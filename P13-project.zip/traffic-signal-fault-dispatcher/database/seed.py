"""Initialize the SQLite database and demonstration resources."""
import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'backend'))
from database import init_db, DB_PATH
init_db()
print(f"Database initialized: {DB_PATH}")
