import os, sqlite3
from werkzeug.security import generate_password_hash
from domain import utcnow, DEMO_CLASSIFICATION

BASE = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.environ.get("DATABASE_PATH", os.path.join(BASE, "traffic_dispatcher.db"))
DISTANCES = {
    "North": {"Alpha": 4, "Beta": 12, "Gamma": 18, "Delta": 25},
    "South": {"Alpha": 20, "Beta": 6, "Gamma": 14, "Delta": 22},
    "East": {"Alpha": 18, "Beta": 15, "Gamma": 5, "Delta": 12},
    "West": {"Alpha": 24, "Beta": 20, "Gamma": 11, "Delta": 7},
}
DEPOTS = [("Alpha","BR-A","DEP-A","TEAM-A"),("Beta","BR-B","DEP-B","TEAM-B"),("Gamma","BR-C","DEP-C","TEAM-C"),("Delta","BR-D","DEP-D","TEAM-D")]

SCHEMA = '''
PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, username TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL, role TEXT NOT NULL CHECK(role IN ('reporter','handler','admin')), handler_id INTEGER);
CREATE TABLE IF NOT EXISTS depots(id INTEGER PRIMARY KEY, name TEXT UNIQUE NOT NULL, branch_id TEXT NOT NULL, depot_id TEXT NOT NULL UNIQUE, team_id TEXT NOT NULL, total_vans INTEGER NOT NULL DEFAULT 3, available_vans INTEGER NOT NULL DEFAULT 3);
CREATE TABLE IF NOT EXISTS handlers(id INTEGER PRIMARY KEY, name TEXT NOT NULL, depot_id INTEGER NOT NULL REFERENCES depots(id), available INTEGER NOT NULL DEFAULT 1, max_capacity INTEGER NOT NULL DEFAULT 2);
CREATE TABLE IF NOT EXISTS distances(id INTEGER PRIMARY KEY, zone TEXT NOT NULL, depot_id INTEGER NOT NULL REFERENCES depots(id), km REAL NOT NULL, UNIQUE(zone,depot_id));
CREATE TABLE IF NOT EXISTS classification_rules(fault_code TEXT PRIMARY KEY, category TEXT NOT NULL, note TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS reports(id INTEGER PRIMARY KEY AUTOINCREMENT, report_id TEXT UNIQUE NOT NULL, reporter_name TEXT NOT NULL, contact TEXT NOT NULL, email TEXT, junction_id TEXT NOT NULL, fault_code TEXT NOT NULL, description TEXT NOT NULL, urgency TEXT, zone TEXT, category TEXT, matched_rule TEXT, priority_rank INTEGER, priority_label TEXT, validation_json TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'Pending', created_at TEXT NOT NULL, updated_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS assignments(id INTEGER PRIMARY KEY AUTOINCREMENT, report_id INTEGER NOT NULL REFERENCES reports(id), depot_id INTEGER NOT NULL REFERENCES depots(id), handler_id INTEGER NOT NULL REFERENCES handlers(id), distance_km REAL NOT NULL, is_backup INTEGER NOT NULL DEFAULT 0, assigned_at TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS routing_decisions(id INTEGER PRIMARY KEY AUTOINCREMENT, report_id INTEGER NOT NULL REFERENCES reports(id), zone TEXT, depot_name TEXT, handler_name TEXT, distance_km REAL, decision TEXT NOT NULL, reason TEXT, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS escalation_history(id INTEGER PRIMARY KEY AUTOINCREMENT, report_id INTEGER NOT NULL REFERENCES reports(id), kind TEXT NOT NULL, reason TEXT NOT NULL, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS status_history(id INTEGER PRIMARY KEY AUTOINCREMENT, report_id INTEGER NOT NULL REFERENCES reports(id), old_status TEXT, new_status TEXT NOT NULL, changed_by TEXT NOT NULL, created_at TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS idx_reports_status ON reports(status);
CREATE INDEX IF NOT EXISTS idx_reports_zone ON reports(zone);
CREATE INDEX IF NOT EXISTS idx_assignments_active ON assignments(active);
'''

def connect():
    con = sqlite3.connect(DB_PATH, timeout=15, isolation_level=None)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys=ON")
    con.execute("PRAGMA busy_timeout=15000")
    return con

def init_db():
    con = connect()
    con.executescript(SCHEMA)
    if con.execute("SELECT COUNT(*) FROM depots").fetchone()[0] == 0:
        for name, branch, depot, team in DEPOTS:
            con.execute("INSERT INTO depots(name,branch_id,depot_id,team_id,total_vans,available_vans) VALUES(?,?,?,?,3,3)",(name,branch,depot,team))
        for zone, row in DISTANCES.items():
            for name, km in row.items():
                did = con.execute("SELECT id FROM depots WHERE name=?",(name,)).fetchone()[0]
                con.execute("INSERT INTO distances(zone,depot_id,km) VALUES(?,?,?)",(zone,did,km))
        for depot_name, in con.execute("SELECT name FROM depots").fetchall():
            did = con.execute("SELECT id FROM depots WHERE name=?",(depot_name,)).fetchone()[0]
            for n in (1,2):
                hid = con.execute("INSERT INTO handlers(name,depot_id,available,max_capacity) VALUES(?,?,1,2)",(f"{depot_name} Handler {n}",did)).lastrowid
                username = f"{depot_name.lower()}handler{n}"
                con.execute("INSERT OR IGNORE INTO users(username,password_hash,role,handler_id) VALUES(?,?,?,?)",(username,generate_password_hash("demo123"),"handler",hid))
        for code, category in DEMO_CLASSIFICATION.items():
            con.execute("INSERT OR IGNORE INTO classification_rules VALUES(?,?,?)",(code,category,"SIMULATION ASSUMPTION — editable demonstration mapping; not an official fault-code standard."))
        con.execute("INSERT OR IGNORE INTO users(username,password_hash,role) VALUES(?,?,?)",("admin",generate_password_hash("admin123"),"admin"))
        con.execute("INSERT OR IGNORE INTO users(username,password_hash,role) VALUES(?,?,?)",("reporter",generate_password_hash("report123"),"reporter"))
    con.close()
