import os, json, uuid
from functools import wraps
from flask import Flask, request, jsonify, g
from flask_cors import CORS
from itsdangerous import URLSafeTimedSerializer, BadSignature, SignatureExpired
from werkzeug.security import check_password_hash
from database import connect, init_db
from domain import validate, classify, zone_from_junction, PRIORITIES, CATEGORIES, utcnow

app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'p13-development-secret-change-before-deployment')
CORS(app, resources={r"/api/*": {"origins": os.environ.get('FRONTEND_ORIGIN', '*')}})
serializer = URLSafeTimedSerializer(app.config['SECRET_KEY'])
init_db()


def token_for(user):
    return serializer.dumps({"username": user['username'], "role": user['role'], "handler_id": user['handler_id']})

def auth(required=None):
    def decorator(fn):
        @wraps(fn)
        def wrapped(*args, **kwargs):
            raw = request.headers.get('Authorization', '').replace('Bearer ', '', 1)
            try:
                payload = serializer.loads(raw, max_age=60*60*12)
            except (BadSignature, SignatureExpired):
                return jsonify(error="Authentication required or session expired."), 401
            if required and payload['role'] not in required:
                return jsonify(error="You are not authorized to perform this operation."), 403
            g.user = payload
            return fn(*args, **kwargs)
        return wrapped
    return decorator

def rowdict(row): return dict(row) if row else None

def active_workload(con, handler_id):
    return con.execute("SELECT COUNT(*) FROM assignments a JOIN reports r ON r.id=a.report_id WHERE a.handler_id=? AND a.active=1 AND r.status!='Resolved'",(handler_id,)).fetchone()[0]

def record_decision(con, rid, zone, depot=None, handler=None, distance=None, decision='Queued', reason=''):
    con.execute("INSERT INTO routing_decisions(report_id,zone,depot_name,handler_name,distance_km,decision,reason,created_at) VALUES(?,?,?,?,?,?,?,?)",
                (rid,zone,depot,handler,distance,decision,reason,utcnow()))

def log_escalation(con, rid, kind, reason):
    con.execute("INSERT INTO escalation_history(report_id,kind,reason,created_at) VALUES(?,?,?,?)",(rid,kind,reason,utcnow()))

def dispatch_one(con, report):
    """Must be called inside BEGIN IMMEDIATE transaction."""
    rid = report['id']; zone = report['zone']; category = report['category']
    if con.execute("SELECT 1 FROM assignments WHERE report_id=? AND active=1",(rid,)).fetchone():
        return
    zone_row = con.execute("SELECT COUNT(*) FROM distances WHERE zone=?",(zone,)).fetchone()[0]
    if not zone_row:
        reason = f"Zone {zone} has no configured routing key; sent to central correction queue."
        record_decision(con,rid,zone,decision='Central fallback queue',reason=reason)
        log_escalation(con,rid,'Unknown zone fallback',reason)
        return
    depots = con.execute("SELECT d.*, x.km FROM distances x JOIN depots d ON d.id=x.depot_id WHERE x.zone=? ORDER BY x.km ASC, d.name ASC",(zone,)).fetchall()
    skipped=[]
    for index, depot in enumerate(depots):
        if depot['available_vans'] <= 0:
            skipped.append(f"{depot['name']}: no available vans"); continue
        handlers = con.execute("SELECT * FROM handlers WHERE depot_id=? AND available=1 ORDER BY id",(depot['id'],)).fetchall()
        eligible = [h for h in handlers if active_workload(con,h['id']) < h['max_capacity']]
        if not eligible:
            skipped.append(f"{depot['name']}: no available handler capacity"); continue
        handler = min(eligible, key=lambda h:(active_workload(con,h['id']),h['id']))
        backup = index > 0
        # Reserve resources and create assignment atomically under the caller's write lock.
        con.execute("UPDATE depots SET available_vans=available_vans-1 WHERE id=? AND available_vans>0",(depot['id'],))
        con.execute("INSERT INTO assignments(report_id,depot_id,handler_id,distance_km,is_backup,assigned_at,active) VALUES(?,?,?,?,?,?,1)",
                    (rid,depot['id'],handler['id'],depot['km'],int(backup),utcnow()))
        con.execute("UPDATE reports SET status='Assigned',updated_at=? WHERE id=?",(utcnow(),rid))
        con.execute("INSERT INTO status_history(report_id,old_status,new_status,changed_by,created_at) VALUES(?,?,?,?,?)",(rid,'Pending','Assigned','dispatch-engine',utcnow()))
        reason = 'Nearest eligible depot selected.' if not backup else 'Primary/nearer depot resource unavailable; assigned to next eligible depot. ' + '; '.join(skipped)
        record_decision(con,rid,zone,depot['name'],handler['name'],depot['km'],'Assigned',reason)
        if backup: log_escalation(con,rid,'Backup depot/handler assignment',reason)
        if category in ('Arterial-Blocked','Signal-Dark'):
            log_escalation(con,rid,'Critical priority treatment',f"{category} report dispatched with priority rank 1.")
        return
    reason = 'No depot currently has both an available van and an eligible handler. ' + '; '.join(skipped)
    record_decision(con,rid,zone,decision='Priority queue',reason=reason)
    if report['priority_rank'] == 1: log_escalation(con,rid,'Critical waiting escalation',reason)

def reprocess_queue(con):
    waiting = con.execute("SELECT * FROM reports WHERE status='Pending' ORDER BY priority_rank ASC, created_at ASC, report_id ASC").fetchall()
    for report in waiting:
        dispatch_one(con,report)

def report_detail(con, report_id):
    return con.execute("""SELECT r.*, d.name depot_name,d.branch_id,d.depot_id,d.team_id,
        h.name handler_name,a.distance_km,a.is_backup,a.assigned_at
        FROM reports r LEFT JOIN assignments a ON a.id=(SELECT ax.id FROM assignments ax WHERE ax.report_id=r.id ORDER BY ax.id DESC LIMIT 1)
        LEFT JOIN depots d ON d.id=a.depot_id LEFT JOIN handlers h ON h.id=a.handler_id
        WHERE r.report_id=?""",(report_id,)).fetchone()

@app.get('/api/health')
def health(): return jsonify(status='ok', service='P13 Traffic Signal Fault Dispatcher')

@app.post('/api/auth/login')
def login():
    data=request.get_json(silent=True) or {}
    con=connect(); user=con.execute("SELECT * FROM users WHERE username=?",(data.get('username',''),)).fetchone(); con.close()
    if not user or not check_password_hash(user['password_hash'],data.get('password','')):
        return jsonify(error='Invalid username or password.'),401
    return jsonify(token=token_for(user), username=user['username'], role=user['role'], handler_id=user['handler_id'])

@app.get('/api/auth/demo-accounts')
def demo_accounts():
    return jsonify(accounts=[{"username":"reporter","password":"report123","role":"reporter"},{"username":"admin","password":"admin123","role":"admin"},{"username":"alphahandler1","password":"demo123","role":"handler"}])

@app.post('/api/reports/validate')
def validate_api():
    data=request.get_json(silent=True) or {}
    result=validate(data.get('junction_id'),data.get('fault_code'))
    return jsonify(result), (200 if result['valid'] else 422)

@app.post('/api/reports')
@auth(['reporter','admin'])
def create_report():
    data=request.get_json(silent=True) or {}
    required=['reporter_name','contact','junction_id','fault_code','description']
    missing=[x for x in required if not str(data.get(x,'')).strip()]
    if missing: return jsonify(error='Missing required fields: '+', '.join(missing)),400
    validation=validate(data['junction_id'],data['fault_code'])
    if not validation['valid']: return jsonify(error='Report rejected during validation.',validation=validation),422
    zone=zone_from_junction(data['junction_id'])
    con=connect()
    try:
        con.execute('BEGIN IMMEDIATE')
        rule=con.execute("SELECT category,note FROM classification_rules WHERE fault_code=?",(data['fault_code'],)).fetchone()
        if not rule:
            con.rollback(); return jsonify(error=f"Fault code {data['fault_code']} is syntactically valid but has no configured classification rule. Ask an administrator to configure it."),422
        category=rule['category']
        if category not in CATEGORIES:
            con.rollback(); return jsonify(error='Configured classification rule is invalid.'),500
        rank,label=PRIORITIES[category]
        report_id='TSF-'+uuid.uuid4().hex[:8].upper()
        now=utcnow()
        cur=con.execute("""INSERT INTO reports(report_id,reporter_name,contact,email,junction_id,fault_code,description,urgency,zone,category,matched_rule,priority_rank,priority_label,validation_json,status,created_at,updated_at)
          VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?, 'Pending',?,?)""",
          (report_id,data['reporter_name'].strip(),data['contact'].strip(),data.get('email'),data['junction_id'],data['fault_code'],data['description'],data.get('urgency','Normal'),zone,category,rule['note']+' '+data['fault_code']+' → '+category,rank,label,json.dumps(validation),now,now))
        con.execute("INSERT INTO status_history(report_id,old_status,new_status,changed_by,created_at) VALUES(?,NULL,'Pending',?,?)",(cur.lastrowid,g.user['username'],now))
        report=con.execute("SELECT * FROM reports WHERE id=?",(cur.lastrowid,)).fetchone()
        dispatch_one(con,report)
        con.commit()
    except Exception:
        con.rollback(); raise
    finally: con.close()
    con=connect(); result=report_detail(con,report_id); con.close()
    return jsonify(report=rowdict(result), validation=validation),201

@app.get('/api/reports')
@auth(['reporter','handler','admin'])
def get_reports():
    con=connect()
    if g.user['role']=='handler':
        rows=con.execute("SELECT r.* FROM reports r JOIN assignments a ON a.report_id=r.id WHERE a.handler_id=? AND a.active=1 ORDER BY r.created_at DESC",(g.user['handler_id'],)).fetchall()
    else: rows=con.execute("SELECT * FROM reports ORDER BY created_at DESC").fetchall()
    con.close(); return jsonify(reports=[dict(x) for x in rows])

@app.get('/api/reports/<report_id>')
@auth(['reporter','handler','admin'])
def get_report(report_id):
    con=connect(); row=report_detail(con,report_id)
    if row and g.user['role']=='handler':
        allowed=con.execute("SELECT 1 FROM assignments WHERE report_id=? AND handler_id=? AND active=1",(row['id'],g.user['handler_id'])).fetchone()
        if not allowed: con.close(); return jsonify(error='This report is not assigned to your handler account.'),403
    con.close()
    if not row: return jsonify(error='Report ID not found.'),404
    return jsonify(report=rowdict(row))

@app.patch('/api/reports/<report_id>/status')
@auth(['handler','admin'])
def update_status(report_id):
    data=request.get_json(silent=True) or {}; new=data.get('status')
    if new not in ('In Progress','Resolved'): return jsonify(error='Status must be In Progress or Resolved.'),400
    con=connect()
    try:
        con.execute('BEGIN IMMEDIATE')
        row=report_detail(con,report_id)
        if not row: con.rollback(); return jsonify(error='Report ID not found.'),404
        if g.user['role']=='handler' and row['handler_name'] is not None:
            own=con.execute("SELECT 1 FROM assignments WHERE report_id=? AND handler_id=? AND active=1",(row['id'],g.user['handler_id'])).fetchone()
            if not own: con.rollback(); return jsonify(error='You can only update reports assigned to you.'),403
        allowed={'Assigned':'In Progress','In Progress':'Resolved'}
        if allowed.get(row['status']) != new: con.rollback(); return jsonify(error=f"Invalid status transition: {row['status']} → {new}."),409
        con.execute("UPDATE reports SET status=?,updated_at=? WHERE id=?",(new,utcnow(),row['id']))
        con.execute("INSERT INTO status_history(report_id,old_status,new_status,changed_by,created_at) VALUES(?,?,?,?,?)",(row['id'],row['status'],new,g.user['username'],utcnow()))
        if new=='Resolved':
            con.execute("UPDATE assignments SET active=0 WHERE report_id=? AND active=1",(row['id'],))
            if row['depot_name']: con.execute("UPDATE depots SET available_vans=MIN(total_vans,available_vans+1) WHERE name=?",(row['depot_name'],))
            reprocess_queue(con)
        con.commit()
    except Exception: con.rollback(); raise
    finally: con.close()
    con=connect(); result=report_detail(con,report_id); con.close()
    return jsonify(report=rowdict(result))

@app.get('/api/reports/<report_id>/history')
@auth(['reporter','handler','admin'])
def report_history(report_id):
    con=connect(); row=con.execute("SELECT id FROM reports WHERE report_id=?",(report_id,)).fetchone()
    if not row: con.close(); return jsonify(error='Report ID not found.'),404
    status=con.execute("SELECT old_status,new_status,changed_by,created_at FROM status_history WHERE report_id=? ORDER BY id",(row['id'],)).fetchall()
    decisions=con.execute("SELECT zone,depot_name,handler_name,distance_km,decision,reason,created_at FROM routing_decisions WHERE report_id=? ORDER BY id",(row['id'],)).fetchall()
    con.close(); return jsonify(status_history=[dict(x) for x in status],routing_history=[dict(x) for x in decisions])

@app.get('/api/handlers')
@auth(['handler','admin'])
def handlers():
    con=connect(); rows=con.execute("SELECT h.*,d.name depot_name FROM handlers h JOIN depots d ON d.id=h.depot_id ORDER BY d.name,h.id").fetchall()
    result=[]
    for h in rows:
        item=dict(h); item['workload']=active_workload(con,h['id']); item['remaining_capacity']=max(0,h['max_capacity']-item['workload']); result.append(item)
    con.close(); return jsonify(handlers=result)

@app.get('/api/handlers/me/reports')
@auth(['handler'])
def my_handler_reports():
    con=connect(); rows=con.execute("SELECT r.*,d.name depot_name,a.distance_km FROM reports r JOIN assignments a ON a.report_id=r.id JOIN depots d ON d.id=a.depot_id WHERE a.handler_id=? AND a.active=1 ORDER BY r.priority_rank,r.created_at",(g.user['handler_id'],)).fetchall(); con.close()
    return jsonify(reports=[dict(x) for x in rows])

@app.patch('/api/handlers/me')
@auth(['handler'])
def update_my_handler():
    data=request.get_json(silent=True) or {}; con=connect(); con.execute('BEGIN IMMEDIATE')
    h=con.execute("SELECT * FROM handlers WHERE id=?",(g.user['handler_id'],)).fetchone()
    if 'max_capacity' in data:
        try: cap=int(data['max_capacity'])
        except: con.rollback(); con.close(); return jsonify(error='Capacity must be an integer.'),400
        if cap<1 or cap<active_workload(con,h['id']): con.rollback(); con.close(); return jsonify(error='Capacity cannot be below current workload and must be at least 1.'),409
        con.execute("UPDATE handlers SET max_capacity=? WHERE id=?",(cap,h['id']))
    if 'available' in data: con.execute("UPDATE handlers SET available=? WHERE id=?",(int(bool(data['available'])),h['id']))
    reprocess_queue(con); con.commit(); con.close(); return jsonify(message='Handler settings updated.')

@app.get('/api/routing/overview')
@auth(['admin'])
def routing_overview():
    con=connect()
    depots=con.execute("SELECT * FROM depots ORDER BY name").fetchall()
    resources=[]
    for d in depots:
        hs=con.execute("SELECT * FROM handlers WHERE depot_id=? ORDER BY id",(d['id'],)).fetchall()
        for h in hs:
            w=active_workload(con,h['id']); resources.append({**dict(h),'depot_name':d['name'],'workload':w,'remaining_capacity':max(0,h['max_capacity']-w)})
    matrix=con.execute("SELECT x.zone,d.name depot_name,x.km FROM distances x JOIN depots d ON d.id=x.depot_id ORDER BY x.zone,x.km").fetchall()
    assignments=con.execute("SELECT r.report_id,r.junction_id,r.zone,r.category,r.priority_label,r.priority_rank,d.name depot_name,d.branch_id,d.team_id,h.name handler_name,a.distance_km,a.assigned_at,a.is_backup FROM assignments a JOIN reports r ON r.id=a.report_id JOIN depots d ON d.id=a.depot_id JOIN handlers h ON h.id=a.handler_id WHERE a.active=1 ORDER BY a.assigned_at DESC").fetchall()
    queue=con.execute("SELECT report_id,junction_id,zone,category,priority_label,priority_rank,created_at FROM reports WHERE status='Pending' ORDER BY priority_rank,created_at,report_id").fetchall()
    decisions=con.execute("SELECT rd.*,r.report_id FROM routing_decisions rd JOIN reports r ON r.id=rd.report_id ORDER BY rd.id DESC LIMIT 100").fetchall()
    escalations=con.execute("SELECT e.*,r.report_id FROM escalation_history e JOIN reports r ON r.id=e.report_id ORDER BY e.id DESC LIMIT 100").fetchall()
    con.close(); return jsonify(depots=[dict(x) for x in depots],handlers=resources,distance_matrix=[dict(x) for x in matrix],assignments=[dict(x) for x in assignments],queue=[dict(x) for x in queue],decisions=[dict(x) for x in decisions],escalations=[dict(x) for x in escalations])

@app.patch('/api/admin/depots/<int:depot_id>')
@auth(['admin'])
def update_depot(depot_id):
    data=request.get_json(silent=True) or {}; con=connect(); con.execute('BEGIN IMMEDIATE')
    d=con.execute("SELECT * FROM depots WHERE id=?",(depot_id,)).fetchone()
    if not d: con.rollback(); con.close(); return jsonify(error='Depot not found.'),404
    if 'available_vans' in data:
        try: value=int(data['available_vans'])
        except: con.rollback(); con.close(); return jsonify(error='Available vans must be an integer.'),400
        if value<0 or value>d['total_vans']: con.rollback(); con.close(); return jsonify(error='Available vans must be between zero and total vans.'),409
        con.execute("UPDATE depots SET available_vans=? WHERE id=?",(value,depot_id))
    reprocess_queue(con); con.commit(); con.close(); return jsonify(message='Depot resources updated.')

@app.patch('/api/admin/handlers/<int:handler_id>')
@auth(['admin'])
def admin_handler_update(handler_id):
    data=request.get_json(silent=True) or {}; con=connect(); con.execute('BEGIN IMMEDIATE')
    h=con.execute("SELECT * FROM handlers WHERE id=?",(handler_id,)).fetchone()
    if not h: con.rollback(); con.close(); return jsonify(error='Handler not found.'),404
    workload=active_workload(con,handler_id)
    if 'max_capacity' in data:
        try: cap=int(data['max_capacity'])
        except: con.rollback(); con.close(); return jsonify(error='Capacity must be an integer.'),400
        if cap<1 or cap<workload: con.rollback(); con.close(); return jsonify(error='Capacity cannot be below current workload.'),409
        con.execute("UPDATE handlers SET max_capacity=? WHERE id=?",(cap,handler_id))
    if 'available' in data: con.execute("UPDATE handlers SET available=? WHERE id=?",(int(bool(data['available'])),handler_id))
    reprocess_queue(con); con.commit(); con.close(); return jsonify(message='Handler resource updated.')

@app.put('/api/admin/classification-rules/<code>')
@auth(['admin'])
def set_rule(code):
    data=request.get_json(silent=True) or {}; category=data.get('category')
    if category not in CATEGORIES: return jsonify(error='Category must be one of the five supported categories.'),400
    con=connect(); con.execute("INSERT INTO classification_rules(fault_code,category,note) VALUES(?,?,?) ON CONFLICT(fault_code) DO UPDATE SET category=excluded.category,note=excluded.note",(code,category,'Administrator-configured rule.')); con.close()
    return jsonify(message='Classification rule saved.',fault_code=code,category=category)

@app.get('/api/admin/classification-rules')
@auth(['admin'])
def get_rules():
    con=connect(); rows=con.execute("SELECT * FROM classification_rules ORDER BY fault_code").fetchall(); con.close(); return jsonify(rules=[dict(x) for x in rows])

@app.get('/api/analytics')
@auth(['reporter','handler','admin'])
def analytics():
    con=connect()
    def grouped(sql): return [dict(x) for x in con.execute(sql).fetchall()]
    total=con.execute("SELECT COUNT(*) FROM reports").fetchone()[0]
    resolved=con.execute("SELECT COUNT(*) FROM reports WHERE status='Resolved'").fetchone()[0]
    statuses=grouped("SELECT status name,COUNT(*) value FROM reports GROUP BY status")
    zones=grouped("SELECT zone name,COUNT(*) value FROM reports GROUP BY zone ORDER BY zone")
    categories=grouped("SELECT category name,COUNT(*) value FROM reports GROUP BY category ORDER BY category")
    priorities=grouped("SELECT priority_label name,COUNT(*) value FROM reports GROUP BY priority_rank,priority_label ORDER BY priority_rank")
    con.close(); return jsonify(total=total,resolved=resolved,unresolved=total-resolved,statuses=statuses,zones=zones,categories=categories,priorities=priorities)

@app.get('/api/queue')
@auth(['admin'])
def queue_api():
    con=connect(); rows=con.execute("SELECT report_id,zone,category,priority_label,created_at,status FROM reports WHERE status='Pending' ORDER BY priority_rank,created_at,report_id").fetchall(); con.close(); return jsonify(queue=[dict(x) for x in rows])

@app.errorhandler(404)
def not_found(_): return jsonify(error='API endpoint not found.'),404
@app.errorhandler(500)
def server_error(_): return jsonify(error='Unexpected server error. Check backend logs.'),500

if __name__ == '__main__': app.run(host='0.0.0.0',port=int(os.environ.get('PORT',5000)),debug=os.environ.get('FLASK_DEBUG')=='1')
