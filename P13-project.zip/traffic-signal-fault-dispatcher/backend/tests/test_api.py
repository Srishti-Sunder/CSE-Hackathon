import os, sys, tempfile
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
import pytest
from database import DB_PATH
import database

@pytest.fixture
def client(tmp_path, monkeypatch):
    monkeypatch.setattr(database, 'DB_PATH', str(tmp_path/'test.db'))
    import app as app_module
    app_module.init_db()
    app_module.app.config['TESTING']=True
    c=app_module.app.test_client()
    def login(username,password):
        r=c.post('/api/auth/login',json={'username':username,'password':password})
        return {'Authorization':'Bearer '+r.json['token']}
    return c, login

def test_health(client):
    c,_=client; assert c.get('/api/health').status_code==200

def test_login_roles(client):
    c,login=client; assert login('admin','admin123')['Authorization'].startswith('Bearer ')

def test_invalid_submission_rejected(client):
    c,login=client; h=login('reporter','report123')
    r=c.post('/api/reports',headers=h,json={'reporter_name':'Test','contact':'123','junction_id':'JNORTH01','fault_code':'F01','description':'dark'})
    assert r.status_code==422

def test_unknown_valid_code_not_minor(client):
    c,login=client; h=login('reporter','report123')
    r=c.post('/api/reports',headers=h,json={'reporter_name':'Test','contact':'123','junction_id':'JNORTH001','fault_code':'F99','description':'unknown'})
    assert r.status_code==422

def test_submission_and_tracking(client):
    c,login=client; h=login('reporter','report123')
    r=c.post('/api/reports',headers=h,json={'reporter_name':'Test','contact':'123','junction_id':'JNORTH001','fault_code':'F01','description':'blocked arterial'})
    assert r.status_code==201 and r.json['report']['category']=='Arterial-Blocked'
    rid=r.json['report']['report_id']; assert c.get('/api/reports/'+rid,headers=h).status_code==200

def test_role_protection(client):
    c,login=client; h=login('reporter','report123')
    assert c.get('/api/routing/overview',headers=h).status_code==403

def test_analytics_empty_and_after_submission(client):
    c,login=client; h=login('reporter','report123')
    assert c.get('/api/analytics',headers=h).json['total']==0
    c.post('/api/reports',headers=h,json={'reporter_name':'Test','contact':'123','junction_id':'JEAST007','fault_code':'F03','description':'partial failure'})
    assert c.get('/api/analytics',headers=h).json['total']==1
