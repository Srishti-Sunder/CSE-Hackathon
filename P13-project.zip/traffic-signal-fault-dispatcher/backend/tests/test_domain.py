import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from domain import dfa_junction, dfa_fault, validate, classify, zone_from_junction

def test_valid_junctions():
    for x in ['JNORTH001','JSOUTH002','JEAST007','JWEST999']: assert dfa_junction(x)
def test_invalid_junctions():
    for x in ['JNORTH01','JNORTH1234','JNORTHABC','NORTH001','JCENTRAL001','JNORTH','']: assert not dfa_junction(x)
def test_valid_faults():
    for x in ['F01','F12','F99']: assert dfa_fault(x)
def test_invalid_faults():
    for x in ['F1','F123','FA1','12','']: assert not dfa_fault(x)
def test_dfa_regex_agreement():
    for j in ['JNORTH001','JWEST999','JNORTH01','JCENTRAL001']:
        for f in ['F01','F1','F123']: assert validate(j,f)['dfa_regex_agree']
def test_all_five_categories():
    from domain import DEMO_CLASSIFICATION
    assert set(DEMO_CLASSIFICATION.values()) == {'Arterial-Blocked','Signal-Dark','Partial-Fault','Flashing-Mode','Minor'}
def test_unknown_classification(): assert classify('F99')[0] is None
def test_zone_extraction(): assert zone_from_junction('JEAST007') == 'East'
def test_invalid_zone_extraction():
    try: zone_from_junction('JCENTRAL001'); assert False
    except ValueError: assert True
